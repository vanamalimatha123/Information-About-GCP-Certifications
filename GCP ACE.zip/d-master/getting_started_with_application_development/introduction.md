# Developing Applications with Google Cloud

## Learning Objectives
- Understand the overall course structure.
