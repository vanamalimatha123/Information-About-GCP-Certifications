# Developing Applications with Google Cloud Platform Specialization

- [Google Cloud Platform Fundamentals: Core Infrastructure](gcp_fundamentals_core_infrastructre/README.md)
- [Getting Started With Application Development](getting_started_with_application_development/README.md)
